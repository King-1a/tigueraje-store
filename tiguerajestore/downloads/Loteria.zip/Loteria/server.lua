-- DDRP Lottery System - Server
-- Author: Angel MTA (2025-09-03)
-- No exports required. Uses SQLite for persistence.

local resRoot = getResourceRootElement(getThisResource())

-- Settings (can be modified via Admin Panel -> Resources -> Settings)
local function getNumSetting(name, default)
    local s = get( name )
    if not s then return default end
    local n = tonumber(s)
    if not n then return default end
    return n
end

local DRAW_INTERVAL_MIN = getNumSetting("*draw_interval_minutes", 5)
local MIN_BET = getNumSetting("*min_bet", 100)
local MAX_BET = getNumSetting("*max_bet", 1000000)
local PAYOUT_MULT = getNumSetting("*payout_multiplier", 70)
local LOCK_SECONDS = getNumSetting("*lock_seconds_before_draw", 10)

-- Marker/Blip settings
local MARKER_POS = Vector3(
    getNumSetting("*marker_x", 1480.0),
    getNumSetting("*marker_y", -1740.0),
    getNumSetting("*marker_z", 13.5)
)
local MARKER_DIM = getNumSetting("*marker_dimension", 0)
local MARKER_INT = getNumSetting("*marker_interior", 0)
local BLIP_ICON = getNumSetting("*blip_icon", 52)
local BLIP_COLOR = {getNumSetting("*blip_color_r", 255), getNumSetting("*blip_color_g", 215), getNumSetting("*blip_color_b", 0)}

-- DB
local db = nil
local function dbExecSafe(...)
    local ok = dbExec(...)
    if not ok then
        outputDebugString("[LOTTERY] dbExec failed!", 1)
    end
    return ok
end

local function initDB()
    db = dbConnect("sqlite", "lottery.db")
    if not db then
        outputDebugString("[LOTTERY] Failed to open SQLite DB", 1)
        cancelEvent()
        return false
    end
    dbExecSafe(db, [[
        CREATE TABLE IF NOT EXISTS bets (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            serial TEXT,
            account TEXT,
            playerName TEXT,
            number INTEGER, -- 0..99 (00 is 0)
            amount INTEGER,
            round INTEGER,
            ts INTEGER
        );
    ]])
    dbExecSafe(db, [[
        CREATE TABLE IF NOT EXISTS payouts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            serial TEXT,
            account TEXT,
            playerName TEXT,
            amount INTEGER,
            round INTEGER,
            number INTEGER,
            winningNumber INTEGER,
            claimed INTEGER DEFAULT 0,
            ts INTEGER
        );
    ]])
    dbExecSafe(db, [[
        CREATE TABLE IF NOT EXISTS history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            round INTEGER UNIQUE,
            winningNumber INTEGER,
            ts INTEGER
        );
    ]])
    return true
end

-- Round state
local currentRound = 1
local nextDrawTick = 0
local marker = nil
local blip = nil

local function formatTwo(n)
    return string.format("%02d", tonumber(n) or 0)
end

local function calcTimeLeft()
    local ms = math.max(0, nextDrawTick - getTickCount())
    return math.floor(ms/1000)
end

local function broadcastToPlayers(ev, ...)
    triggerClientEvent(root, ev, resourceRoot, ...)
end

local function getPlayerIdents(plr)
    local serial = getPlayerSerial(plr) or "unknown"
    local acc = getPlayerAccount(plr)
    local accName = isGuestAccount(acc) and "guest" or getAccountName(acc)
    return serial, accName
end

local function drawRound()
    -- lock bets immediately
    local winning = math.random(0, 99)
    local now = getRealTime().timestamp

    -- Get all bets for this round
    local qh = dbQuery(db, "SELECT id, serial, account, playerName, number, amount FROM bets WHERE round=?", currentRound)
    local bets = dbPoll(qh, -1) or {}

    -- Compute and pay/store
    local totalWinners, totalPaid = 0, 0
    for _, row in ipairs(bets) do
        if tonumber(row.number) == winning then
            totalWinners = totalWinners + 1
            local prize = math.floor(tonumber(row.amount) * PAYOUT_MULT)
            totalPaid = totalPaid + prize

            -- Try pay online
            local paid = false
            for _, p in ipairs(getElementsByType("player")) do
                if getPlayerSerial(p) == row.serial then
                    givePlayerMoney(p, prize)
                    outputChatBox(string.format("[Lotería] ¡%s ganó $%s con el número %s!", row.playerName, tostring(prize), formatTwo(winning)), p, 0, 255, 0)
                    paid = true
                    break
                end
            end
            -- Store payout if not online
            if not paid then
                dbExecSafe(db, "INSERT INTO payouts(serial, account, playerName, amount, round, number, winningNumber, claimed, ts) VALUES(?,?,?,?,?,?,?,?,?)",
                    row.serial, row.account, row.playerName, prize, currentRound, row.number, winning, 0, now)
            end
        end
    end

    -- Save history
    dbExecSafe(db, "INSERT OR REPLACE INTO history(round, winningNumber, ts) VALUES(?,?,?)", currentRound, winning, now)

    -- Announce result
    outputChatBox(string.format("[Lotería] Sorteo #%d: número ganador %s. Premiados: %d.", currentRound, formatTwo(winning), totalWinners), root, 255, 215, 0)

    -- Start next round
    currentRound = currentRound + 1
    nextDrawTick = getTickCount() + (DRAW_INTERVAL_MIN * 60 * 1000)

    -- Inform clients
    broadcastToPlayers("lotto:state", {
        round=currentRound,
        timeLeft=calcTimeLeft(),
        lockSeconds=LOCK_SECONDS,
        minBet=MIN_BET,
        maxBet=MAX_BET,
        payoutMult=PAYOUT_MULT
    })
end

local function startRoundLoop()
    math.randomseed(getRealTime().timestamp)
    nextDrawTick = getTickCount() + (DRAW_INTERVAL_MIN * 60 * 1000)
    setTimer(function()
        drawRound()
    end, DRAW_INTERVAL_MIN * 60 * 1000, 0)
end

-- Marker & blip
local function createWorldObjects()
    marker = createMarker(MARKER_POS.x, MARKER_POS.y, MARKER_POS.z-1.0, "cylinder", 1.2, 255, 215, 0, 120)
    setElementInterior(marker, MARKER_INT)
    setElementDimension(marker, MARKER_DIM)
    setElementData(marker, "ddrp:lottery", true)
    blip = createBlipAttachedTo(marker, BLIP_ICON, 2.0, BLIP_COLOR[0 or 1] or 255, BLIP_COLOR[1 or 2] or 215, BLIP_COLOR[2 or 3] or 0, 255, 0, 99999.0)
    -- Fallback to correct color setting (MTA uses r,g,b as numbers, 1-indexed in Lua)
    setBlipColor(blip, BLIP_COLOR[1], BLIP_COLOR[2], BLIP_COLOR[3], 255)
end

-- Helper: clean player's unclaimed payouts on join
local function payPendingForPlayer(plr)
    local serial, accName = getPlayerIdents(plr)
    local qh = dbQuery(db, "SELECT id, amount FROM payouts WHERE serial=? AND claimed=0", serial)
    local rows = dbPoll(qh, -1) or {}
    local total = 0
    for _, r in ipairs(rows) do
        total = total + tonumber(r.amount)
        givePlayerMoney(plr, r.amount)
        dbExecSafe(db, "UPDATE payouts SET claimed=1 WHERE id=?", r.id)
    end
    if total > 0 then
        outputChatBox(string.format("[Lotería] Tienes premios pendientes por $%d. ¡Ya fueron acreditados!", total), plr, 0, 255, 0)
    end
end

addEventHandler("onPlayerJoin", root, function()
    -- wait a tick to ensure serial available
    setTimer(function(p) if isElement(p) then payPendingForPlayer(p) end end, 1500, 1, source)
end)

addEvent("lotto:placeBet", true)
addEventHandler("lotto:placeBet", resRoot, function(numberStr, amount)
    local plr = client
    if not isElement(plr) then return end

    -- Round lock check
    local timeLeft = calcTimeLeft()
    if timeLeft <= LOCK_SECONDS then
        outputChatBox("[Lotería] Las apuestas están cerradas. Intenta en el siguiente sorteo.", plr, 255, 100, 100)
        return
    end

    -- Validate inputs
    local n
    if numberStr == "00" then n = 0 else n = tonumber(numberStr) end
    if not n or n < 0 or n > 99 then
        outputChatBox("[Lotería] Número inválido. Usa 00-99.", plr, 255, 100, 100)
        return
    end

    amount = tonumber(amount)
    if not amount or amount < MIN_BET or amount > MAX_BET then
        outputChatBox(string.format("[Lotería] Monto inválido. Min: $%d, Max: $%d.", MIN_BET, MAX_BET), plr, 255, 100, 100)
        return
    end

    if getPlayerMoney(plr) < amount then
        outputChatBox("[Lotería] No tienes suficiente dinero.", plr, 255, 100, 100)
        return
    end

    -- Take money and store bet
    takePlayerMoney(plr, amount)
    local serial, accName = getPlayerIdents(plr)
    dbExecSafe(db, "INSERT INTO bets(serial, account, playerName, number, amount, round, ts) VALUES(?,?,?,?,?,?,?)",
        serial, accName, getPlayerName(plr), n, amount, currentRound, getRealTime().timestamp)

    outputChatBox(string.format("[Lotería] Apuesta registrada: #%d - Número %s por $%d.", currentRound, (n==0 and "00" or string.format("%02d", n)), amount), plr, 255, 215, 0)

    -- Update client's bet list
    triggerClientEvent(plr, "lotto:yourBetPlaced", resourceRoot, {round=currentRound, number=n, amount=amount})
end)

addEvent("lotto:requestState", true)
addEventHandler("lotto:requestState", resRoot, function()
    local plr = client
    if not isElement(plr) then return end
    -- history: last 10
    local qh = dbQuery(db, "SELECT round, winningNumber, ts FROM history ORDER BY round DESC LIMIT 10")
    local hist = dbPoll(qh, -1) or {}
    triggerClientEvent(plr, "lotto:state", resourceRoot, {
        round=currentRound,
        timeLeft=calcTimeLeft(),
        lockSeconds=LOCK_SECONDS,
        minBet=MIN_BET,
        maxBet=MAX_BET,
        payoutMult=PAYOUT_MULT,
        history=hist
    })
end)

-- Resource start
addEventHandler("onResourceStart", resRoot, function()
    if not initDB() then return end
    createWorldObjects()
    startRoundLoop()
    outputDebugString("[LOTTERY] Resource started. Interval: "..DRAW_INTERVAL_MIN.." min, Payout x"..PAYOUT_MULT)
end)

-- Admin command to force draw
addCommandHandler("lotto_draw_now", function(plr)
    if plr and not isObjectInACLGroup("user."..getAccountName(getPlayerAccount(plr)), aclGetGroup("Admin")) then
        outputChatBox("Comando solo para Admin.", plr, 255, 100, 100)
        return
    end
    drawRound()
end)
