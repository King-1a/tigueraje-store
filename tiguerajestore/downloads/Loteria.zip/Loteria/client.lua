-- Lottery System - Client
local resRoot = getResourceRootElement(getThisResource())

local ui = {
    wnd=nil, lblInfo=nil, editNumber=nil, editAmount=nil, btnBet=nil, btnClose=nil,
    lblHistory=nil, gridBets=nil, lblLock=nil
}

local function formatTwo(n)
    return string.format("%02d", tonumber(n) or 0)
end

-- Open GUI
local function openUI()
    if ui.wnd and isElement(ui.wnd) then
        guiSetVisible(ui.wnd, true)
        showCursor(true)
        return
    end

    local sx, sy = guiGetScreenSize()
    ui.wnd = guiCreateWindow(sx/2-220, sy/2-170, 440, 340, "Lotería - Name Server", false)
    guiWindowSetSizable(ui.wnd, false)

    ui.lblInfo = guiCreateLabel(15, 30, 410, 40, "Apuesta tu número (00-99). Pago x? al acertar.", false, ui.wnd)
    guiLabelSetHorizontalAlign(ui.lblInfo, "left", true)

    guiCreateLabel(15, 80, 100, 20, "Número (00-99):", false, ui.wnd)
    ui.editNumber = guiCreateEdit(120, 78, 60, 24, "", false, ui.wnd)
    guiEditSetMaxLength(ui.editNumber, 2)

    guiCreateLabel(200, 80, 100, 20, "Monto ($):", false, ui.wnd)
    ui.editAmount = guiCreateEdit(270, 78, 120, 24, "", false, ui.wnd)

    ui.btnBet = guiCreateButton(15, 115, 180, 34, "Apostar", false, ui.wnd)
    ui.btnClose = guiCreateButton(210, 115, 180, 34, "Cerrar", false, ui.wnd)

    ui.lblLock = guiCreateLabel(15, 155, 410, 18, "", false, ui.wnd)
    guiLabelSetColor(ui.lblLock, 255, 120, 120)

    ui.lblHistory = guiCreateLabel(15, 175, 410, 18, "Últimos resultados:", false, ui.wnd)

    ui.gridBets = guiCreateGridList(15, 195, 410, 130, false, ui.wnd)
    guiGridListAddColumn(ui.gridBets, "Info", 0.9)

    addEventHandler("onClientGUIClick", ui.btnClose, function()
        if ui.wnd and isElement(ui.wnd) then
            guiSetVisible(ui.wnd, false)
            showCursor(false)
        end
    end, false)

    addEventHandler("onClientGUIClick", ui.btnBet, function()
        local number = guiGetText(ui.editNumber)
        number = number:gsub("%s+", "")
        if number == "00" then
            -- ok
        else
            local n = tonumber(number)
            if not n or n < 0 or n > 99 then
                outputChatBox("[Lotería] Número inválido. Usa 00-99.", 255, 100, 100)
                return
            end
            number = string.format("%02d", n)
        end
        local amount = tonumber(guiGetText(ui.editAmount) or "0") or 0
        triggerServerEvent("lotto:placeBet", resourceRoot, number, amount)
    end, false)

    showCursor(true)
    triggerServerEvent("lotto:requestState", resourceRoot)
end

-- Update UI state
local state = {round=1, timeLeft=0, lockSeconds=10, minBet=100, maxBet=1000000, payoutMult=70}

local function refreshLabels()
    if not ui.wnd or not isElement(ui.wnd) then return end
    guiSetText(ui.lblInfo, string.format("Apuesta tu número (00-99). Pago x%d al acertar.\nMín: $%d | Máx: $%d | Sorteo #%d en %ds",
        state.payoutMult, state.minBet, state.maxBet, state.round, math.max(0, state.timeLeft)))
    if state.timeLeft <= state.lockSeconds then
        guiSetText(ui.lblLock, string.format("Apuestas cerradas. Espera al próximo sorteo. (faltan %ds)", math.max(0, state.timeLeft)))
    else
        guiSetText(ui.lblLock, "")
    end
end

setTimer(function()
    state.timeLeft = math.max(0, state.timeLeft - 1)
    refreshLabels()
end, 1000, 0)

addEvent("lotto:state", true)
addEventHandler("lotto:state", resourceRoot, function(s)
    for k,v in pairs(s) do state[k]=v end
    refreshLabels()

    if ui.gridBets and isElement(ui.gridBets) then
        guiGridListClear(ui.gridBets)
        if s.history then
            for _,h in ipairs(s.history) do
                local row = guiGridListAddRow(ui.gridBets)
                guiGridListSetItemText(ui.gridBets, row, 1, string.format("Sorteo #%d -> Ganador: %s", h.round, formatTwo(h.winningNumber)), false, false)
            end
        end
    end
end)

addEvent("lotto:yourBetPlaced", true)
addEventHandler("lotto:yourBetPlaced", resourceRoot, function(info)
    -- Show feedback in grid (top row)
    if ui.gridBets and isElement(ui.gridBets) then
        local row = guiGridListAddRow(ui.gridBets)
        guiGridListSetItemText(ui.gridBets, row, 1, string.format("Apuesta #%d -> Número %s por $%d", info.round, formatTwo(info.number), info.amount), false, false)
    end
end)

-- Open UI at marker
addEventHandler("onClientMarkerHit", root, function(player, mDim)
    if player ~= localPlayer then return end
    if not getElementData(source, "ddrp:lottery") then return end
    if not mDim then return end
    openUI()
end)

-- Command to open UI (only near marker for fairness)
addCommandHandler("lotto", function()
    openUI()
end)
